# Policy RBACProhibitListOnSecrets

Policy to reject RBAC roles allowing list on secrets. It is part of [Kubernetes RBAC Good Practices](https://kubernetes.io/docs/concepts/security/rbac-good-practices)

Created out of [RBACProhibitVerbsOnResources](../../examples/RBACProhibitVerbsOnResources)


