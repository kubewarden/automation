# Policy RBACProhibitWildcardOnSecrets

Policy to reject RBAC roles allowing wildcard on secrets. It is part of [Kubernetes RBAC Good Practices](https://kubernetes.io/docs/concepts/security/rbac-good-practices)

Created out of [RBACProhibitVerbsOnResources](../../examples/RBACProhibitVerbsOnResources)


